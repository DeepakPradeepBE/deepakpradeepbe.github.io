import boto3
import os 

cw_client = boto3.client('cloudwatch')
cw_logs_client = boto3.client('logs')

def create_log_metric(filter,filter_name):

    cloudtrail_log_group_name = os.environ['cloudtrail_log_group_name']

    response = cw_logs_client.put_metric_filter(
    logGroupName=cloudtrail_log_group_name,
    filterName= f'{filter_name}-metric-filter',
    filterPattern= filter,
    metricTransformations=[
        {
            'metricName': f'{filter_name}-metric-filter',
            'metricNamespace': 'LogMetrics',
            'metricValue': '1',
            'defaultValue': 0,
        },
        ]
    )

    print("done")

def create_cw_alarm(filter_name):
    
    sns_topic_arn = os.environ['sns_topic_arn']

    response = cw_client.put_metric_alarm(
        AlarmName=f'{filter_name}-alarm',
        ComparisonOperator='GreaterThanThreshold',
        EvaluationPeriods=300,
        MetricName=f'{filter_name}-metric-filter',
        Namespace='LogMetrics',
        Period=60,
        Statistic='Average',
        Threshold=1,
        AlarmDescription=f'Alarm create for {filter_name} cloudwatch security hub control',
        ActionsEnabled=True,
        AlarmActions=[
            sns_topic_arn,
        ],
        Unit='Seconds'
    )

    print("done")

def lambda_handler(event, context):
    cloud_watch_control_id = message = event['Records'][0]['Sns']['Message']
    
    if cloud_watch_control_id == "cloudwatch1":
        filter = "{$.userIdentity.type=\"Root\" && $.userIdentity.invokedBy NOT EXISTS && $.eventType !=\"AwsServiceEvent\"}"
        filter_name = "cis"
    elif cloud_watch_control_id == "cloudwatch2":
        filter = "{($.errorCode=\"*UnauthorizedOperation\") || ($.errorCode=\"AccessDenied*\")}"
        filter_name = "unauthorized-api-calls"
    elif cloud_watch_control_id == "cloudwatch4":
        filter = "{($.eventSource=iam.amazonaws.com) && (($.eventName=DeleteGroupPolicy) || ($.eventName=DeleteRolePolicy) || ($.eventName=DeleteUserPolicy) || ($.eventName=PutGroupPolicy) || ($.eventName=PutRolePolicy) || ($.eventName=PutUserPolicy) || ($.eventName=CreatePolicy) || ($.eventName=DeletePolicy) || ($.eventName=CreatePolicyVersion) || ($.eventName=DeletePolicyVersion) || ($.eventName=AttachRolePolicy) || ($.eventName=DetachRolePolicy) || ($.eventName=AttachUserPolicy) || ($.eventName=DetachUserPolicy) || ($.eventName=AttachGroupPolicy) || ($.eventName=DetachGroupPolicy))}"
        filter_name = "aws-iam-policy-changes"
    elif cloud_watch_control_id == "cloudwatch5":
        filter =  "{($.eventName=CreateTrail) || ($.eventName=UpdateTrail) || ($.eventName=DeleteTrail) || ($.eventName=StartLogging) || ($.eventName=StopLogging)}"
        filter_name = "aws-cloud-trail-changes"
    elif cloud_watch_control_id == "cloudwatch9":
        filter =  "{($.eventSource=config.amazonaws.com) && (($.eventName=StopConfigurationRecorder) || ($.eventName=DeleteDeliveryChannel) || ($.eventName=PutDeliveryChannel) || ($.eventName=PutConfigurationRecorder))}"
        filter_name = "aws-config-changes"
    elif cloud_watch_control_id == "cloudwatch10":
        filter = "{($.eventName=AuthorizeSecurityGroupIngress) || ($.eventName=AuthorizeSecurityGroupEgress) || ($.eventName=RevokeSecurityGroupIngress) || ($.eventName=RevokeSecurityGroupEgress) || ($.eventName=CreateSecurityGroup) || ($.eventName=DeleteSecurityGroup)}"
        filter_name = "aws-sg-changes"
    elif cloud_watch_control_id == "cloudwatch11":
        filter = "{($.eventName=CreateNetworkAcl) || ($.eventName=CreateNetworkAclEntry) || ($.eventName=DeleteNetworkAcl) || ($.eventName=DeleteNetworkAclEntry) || ($.eventName=ReplaceNetworkAclEntry) || ($.eventName=ReplaceNetworkAclAssociation)}"
        filter_name = "aws-nacl-changes"
    elif cloud_watch_control_id == "cloudwatch12":
        filter = "{($.eventName=CreateCustomerGateway) || ($.eventName=DeleteCustomerGateway) || ($.eventName=AttachInternetGateway) || ($.eventName=CreateInternetGateway) || ($.eventName=DeleteInternetGateway) || ($.eventName=DetachInternetGateway)}"
        filter_name = "aws-network-gw-changes"
    elif cloud_watch_control_id == "cloudwatch13":
        filter = "{($.eventSource=ec2.amazonaws.com) && (($.eventName=CreateRoute) || ($.eventName=CreateRouteTable) || ($.eventName=ReplaceRoute) || ($.eventName=ReplaceRouteTableAssociation) || ($.eventName=DeleteRouteTable) || ($.eventName=DeleteRoute) || ($.eventName=DisassociateRouteTable))}"
        filter_name = "aws-route-table-changes"
    elif cloud_watch_control_id == "cloudwatch14":
        filter = "{($.eventName=CreateVpc) || ($.eventName=DeleteVpc) || ($.eventName=ModifyVpcAttribute) || ($.eventName=AcceptVpcPeeringConnection) || ($.eventName=CreateVpcPeeringConnection) || ($.eventName=DeleteVpcPeeringConnection) || ($.eventName=RejectVpcPeeringConnection) || ($.eventName=AttachClassicLinkVpc) || ($.eventName=DetachClassicLinkVpc) || ($.eventName=DisableVpcClassicLink) || ($.eventName=EnableVpcClassicLink)}"
        filter_name = "aws-vpc-changes"

    create_log_metric(filter, filter_name)
    create_cw_alarm(filter_name)