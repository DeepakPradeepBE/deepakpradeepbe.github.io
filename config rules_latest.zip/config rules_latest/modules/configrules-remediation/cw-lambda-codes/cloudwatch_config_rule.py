import boto3
import json


cw_logs_client = boto3.client('logs')
config_client = boto3.client('config')

def metric_filter_status(filter, cloudtrail_log_group):
    response = cw_logs_client.describe_metric_filters(
      logGroupName=cloudtrail_log_group,
    )
    metric_filter_status = 'NON_COMPLIANT'
    try:
        for metric in response["metricFilters"]:
            if filter == metric["filterPattern"]:
                metric_filter_status = 'COMPLIANT'
                break
    except Exception as e:
        print(f"An error occurred: {e}")

    return metric_filter_status

def lambda_handler(event, context):

    invoking_event = json.loads(event['invokingEvent'])

    rule_parameters_json = json.loads(event['ruleParameters'])
    cloudtrail_log_group = rule_parameters_json['cloudtrailLogGroup']
    cloud_watch_control_id = rule_parameters_json['cloud_watch_control_id']
    
    if cloud_watch_control_id == "cloudwatch1":
        filter = "{$.userIdentity.type=\"Root\" && $.userIdentity.invokedBy NOT EXISTS && $.eventType !=\"AwsServiceEvent\"}"
    elif cloud_watch_control_id == "cloudwatch2":
        filter = "{($.errorCode=\"*UnauthorizedOperation\") || ($.errorCode=\"AccessDenied*\")}"
    elif cloud_watch_control_id == "cloudwatch4":
        filter = "{($.eventSource=iam.amazonaws.com) && (($.eventName=DeleteGroupPolicy) || ($.eventName=DeleteRolePolicy) || ($.eventName=DeleteUserPolicy) || ($.eventName=PutGroupPolicy) || ($.eventName=PutRolePolicy) || ($.eventName=PutUserPolicy) || ($.eventName=CreatePolicy) || ($.eventName=DeletePolicy) || ($.eventName=CreatePolicyVersion) || ($.eventName=DeletePolicyVersion) || ($.eventName=AttachRolePolicy) || ($.eventName=DetachRolePolicy) || ($.eventName=AttachUserPolicy) || ($.eventName=DetachUserPolicy) || ($.eventName=AttachGroupPolicy) || ($.eventName=DetachGroupPolicy))}"
    elif cloud_watch_control_id == "cloudwatch5":
        filter =  "{($.eventName=CreateTrail) || ($.eventName=UpdateTrail) || ($.eventName=DeleteTrail) || ($.eventName=StartLogging) || ($.eventName=StopLogging)}"
    elif cloud_watch_control_id == "cloudwatch9":
        filter =  "{($.eventSource=config.amazonaws.com) && (($.eventName=StopConfigurationRecorder) || ($.eventName=DeleteDeliveryChannel) || ($.eventName=PutDeliveryChannel) || ($.eventName=PutConfigurationRecorder))}"
    elif cloud_watch_control_id == "cloudwatch10":
        filter = "{($.eventName=AuthorizeSecurityGroupIngress) || ($.eventName=AuthorizeSecurityGroupEgress) || ($.eventName=RevokeSecurityGroupIngress) || ($.eventName=RevokeSecurityGroupEgress) || ($.eventName=CreateSecurityGroup) || ($.eventName=DeleteSecurityGroup)}"
    elif cloud_watch_control_id == "cloudwatch11":
        filter = "{($.eventName=CreateNetworkAcl) || ($.eventName=CreateNetworkAclEntry) || ($.eventName=DeleteNetworkAcl) || ($.eventName=DeleteNetworkAclEntry) || ($.eventName=ReplaceNetworkAclEntry) || ($.eventName=ReplaceNetworkAclAssociation)}"
    elif cloud_watch_control_id == "cloudwatch12":
        filter = "{($.eventName=CreateCustomerGateway) || ($.eventName=DeleteCustomerGateway) || ($.eventName=AttachInternetGateway) || ($.eventName=CreateInternetGateway) || ($.eventName=DeleteInternetGateway) || ($.eventName=DetachInternetGateway)}"
    elif cloud_watch_control_id == "cloudwatch13":
        filter = "{($.eventSource=ec2.amazonaws.com) && (($.eventName=CreateRoute) || ($.eventName=CreateRouteTable) || ($.eventName=ReplaceRoute) || ($.eventName=ReplaceRouteTableAssociation) || ($.eventName=DeleteRouteTable) || ($.eventName=DeleteRoute) || ($.eventName=DisassociateRouteTable))}"
    elif cloud_watch_control_id == "cloudwatch14":
        filter = "{($.eventName=CreateVpc) || ($.eventName=DeleteVpc) || ($.eventName=ModifyVpcAttribute) || ($.eventName=AcceptVpcPeeringConnection) || ($.eventName=CreateVpcPeeringConnection) || ($.eventName=DeleteVpcPeeringConnection) || ($.eventName=RejectVpcPeeringConnection) || ($.eventName=AttachClassicLinkVpc) || ($.eventName=DetachClassicLinkVpc) || ($.eventName=DisableVpcClassicLink) || ($.eventName=EnableVpcClassicLink)}"

    compilant_status = metric_filter_status(filter, cloudtrail_log_group)

    response = config_client.put_evaluations(
    Evaluations=[
        {
            'ComplianceResourceType': 'AWS::CloudWatch::Alarm',
            'ComplianceResourceId': cloud_watch_control_id,
            'ComplianceType': compilant_status,
            'OrderingTimestamp': invoking_event['notificationCreationTime']
        },
    ],
    ResultToken=event['resultToken'])